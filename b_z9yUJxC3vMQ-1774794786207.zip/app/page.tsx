"use client"

import { useState, useEffect } from "react"

// ============================================
// SECURITY CHECK DEFINITIONS
// Each check has a name, description, weight for scoring,
// and a function that returns true if the check FAILS (risk detected)
// ============================================

type SecurityCheck = {
  id: string
  name: string
  description: string
  weight: number // How much this contributes to risk score (out of 100)
  check: (url: string, urlObj: URL) => boolean // Returns true if FAILED
}

const SECURITY_CHECKS: SecurityCheck[] = [
  // Check 1: Suspicious keywords in URL
  {
    id: "suspicious-keywords",
    name: "Suspicious Keywords Detected",
    description: "URL contains phishing-related keywords commonly used in scams",
    weight: 30,
    check: (url: string) => {
      const suspiciousKeywords = [
        "free-money",
        "freemoney",
        "winner",
        "prize",
        "click-now",
        "clicknow",
        "verify-account",
        "verifyaccount",
        "verify-your",
        "otp",
        "urgent",
        "suspended",
        "confirm-identity",
        "update-payment",
        "claim-reward",
        "lucky",
        "congratulations",
        "act-now",
        "limited-time",
        "expire",
        "password-reset",
        "security-alert",
        "unusual-activity",
        // Indian-specific phishing keywords
        "paytm-kyc",
        "sbi-verify",
        "hdfc-update",
        "aadhaar-link",
        "pan-verify",
        "refund-claim",
        "kyc-update",
        "kyc-verify",
        "bank-verify",
        "upi-verify",
      ]
      const lowerUrl = url.toLowerCase()
      return suspiciousKeywords.some((keyword) => lowerUrl.includes(keyword))
    },
  },
  // Check 2: Suspicious top-level domains
  {
    id: "suspicious-domain",
    name: "Suspicious Domain Extension",
    description: "Uses a domain extension commonly associated with malicious websites",
    weight: 25,
    check: (_url: string, urlObj: URL) => {
      const suspiciousTLDs = [
        ".xyz",
        ".tk",
        ".ml",
        ".ga",
        ".cf",
        ".gq",
        ".top",
        ".work",
        ".click",
        ".link",
        ".buzz",
        ".loan",
        ".racing",
        ".review",
        ".country",
        ".stream",
        ".download",
        ".win",
        ".bid",
        ".party",
      ]
      const hostname = urlObj.hostname.toLowerCase()
      return suspiciousTLDs.some((tld) => hostname.endsWith(tld))
    },
  },
  // Check 3: Missing HTTPS (insecure connection)
  {
    id: "no-https",
    name: "Insecure Connection (No HTTPS)",
    description: "Website does not use encrypted HTTPS connection",
    weight: 20,
    check: (_url: string, urlObj: URL) => {
      return urlObj.protocol !== "https:"
    },
  },
  // Check 4: Too many subdomains (potential phishing)
  {
    id: "too-many-subdomains",
    name: "Excessive Subdomains",
    description: "URL has too many subdomains, often used to disguise malicious sites",
    weight: 15,
    check: (_url: string, urlObj: URL) => {
      const hostname = urlObj.hostname
      // Remove www. prefix for counting
      const cleanHostname = hostname.replace(/^www\./, "")
      // Count dots (subdomains create additional dots)
      const dotCount = (cleanHostname.match(/\./g) || []).length
      // More than 2 dots means excessive subdomains (e.g., sub.sub.domain.com)
      return dotCount > 2
    },
  },
  // Check 5: IP address instead of domain name
  {
    id: "ip-address",
    name: "IP Address Instead of Domain",
    description: "URL uses an IP address instead of a domain name, often used in phishing",
    weight: 10,
    check: (_url: string, urlObj: URL) => {
      const hostname = urlObj.hostname
      // Check for IPv4 pattern
      const ipv4Pattern = /^(\d{1,3}\.){3}\d{1,3}$/
      // Check for IPv6 pattern (simplified)
      const ipv6Pattern = /^[\da-f:]+$/i
      return ipv4Pattern.test(hostname) || (hostname.includes(":") && ipv6Pattern.test(hostname))
    },
  },
]

type FailedCheck = {
  name: string
  description: string
}

type ScanResult = {
  status: "safe" | "warning" | "dangerous"
  riskScore: number
  failedChecks: FailedCheck[]
  totalChecks: number
} | null

// History item type for storing scan results
type HistoryItem = {
  id: string
  url: string
  status: "safe" | "warning" | "dangerous"
  riskScore: number
  timestamp: number
}

// Message scan result type
type MessageScanResult = {
  verdict: "SAFE" | "SUSPICIOUS" | "DANGEROUS"
  threat_score: number
  signals: string[]
  summary: string
} | null

// Scanning step for animation
type ScanningStep = {
  label: string
  completed: boolean
  active: boolean
}

const HISTORY_KEY = "safecheck_history"
const MAX_HISTORY_ITEMS = 10

// Pre-loaded example scam messages (Indian context)
const EXAMPLE_MESSAGES = [
  {
    label: "KYC Scam",
    text: "Dear customer, your KYC is expired. Click http://sbi-kyc-update.tk to update immediately or your account will be blocked within 24 hours.",
  },
  {
    label: "Lucky Draw Scam",
    text: "Congratulations! You have won Rs 50,000 in our lucky draw. Call 9876543210 now to claim your prize. Limited time offer!",
  },
  {
    label: "UPI Fraud",
    text: "Your UPI payment of Rs 9,999 has failed. Verify your account at http://upi-verify-now.xyz or funds will be deducted automatically.",
  },
]

export default function SafeCheck() {
  // Tab state
  const [activeTab, setActiveTab] = useState<"url" | "message">("url")

  // URL Scanner state
  const [url, setUrl] = useState("")
  const [isScanning, setIsScanning] = useState(false)
  const [result, setResult] = useState<ScanResult>(null)
  const [scannedUrl, setScannedUrl] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [history, setHistory] = useState<HistoryItem[]>([])

  // Message Scanner state
  const [message, setMessage] = useState("")
  const [isMessageScanning, setIsMessageScanning] = useState(false)
  const [messageResult, setMessageResult] = useState<MessageScanResult>(null)
  const [messageError, setMessageError] = useState<string | null>(null)
  const [scanningSteps, setScanningSteps] = useState<ScanningStep[]>([])

  // Load history from localStorage on mount
  useEffect(() => {
    const savedHistory = localStorage.getItem(HISTORY_KEY)
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory))
      } catch {
        // Invalid JSON, clear it
        localStorage.removeItem(HISTORY_KEY)
      }
    }
  }, [])

  // Save history to localStorage whenever it changes
  useEffect(() => {
    if (history.length > 0) {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(history))
    }
  }, [history])

  // Add scan result to history
  const addToHistory = (url: string, status: "safe" | "warning" | "dangerous", riskScore: number) => {
    const newItem: HistoryItem = {
      id: Date.now().toString(),
      url,
      status,
      riskScore,
      timestamp: Date.now(),
    }
    setHistory((prev) => {
      const updated = [newItem, ...prev].slice(0, MAX_HISTORY_ITEMS)
      localStorage.setItem(HISTORY_KEY, JSON.stringify(updated))
      return updated
    })
  }

  // Clear all history
  const clearHistory = () => {
    setHistory([])
    localStorage.removeItem(HISTORY_KEY)
  }

  // Format timestamp for display
  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp)
    return date.toLocaleString()
  }

  const scanUrl = async () => {
    // Validate input - ensure URL is not empty
    if (!url.trim()) return

    // Reset state for new scan
    setIsScanning(true)
    setResult(null)
    setError(null)

    // Add protocol if missing for proper parsing
    let urlToScan = url.trim()
    if (!urlToScan.startsWith("http://") && !urlToScan.startsWith("https://")) {
      urlToScan = "http://" + urlToScan
    }
    setScannedUrl(urlToScan)

    // Simulate network delay for better UX
    await new Promise((resolve) => setTimeout(resolve, 1500))

    try {
      // Parse URL for analysis
      const urlObj = new URL(urlToScan)

      // Run all security checks
      const failedChecks: FailedCheck[] = []
      let riskScore = 0

      for (const check of SECURITY_CHECKS) {
        const failed = check.check(urlToScan, urlObj)
        if (failed) {
          failedChecks.push({
            name: check.name,
            description: check.description,
          })
          riskScore += check.weight
        }
      }

      // Cap risk score at 100
      riskScore = Math.min(riskScore, 100)

      // Determine status based on risk score
      let status: "safe" | "warning" | "dangerous"
      if (riskScore === 0) {
        status = "safe"
      } else if (riskScore < 30) {
        status = "warning"
      } else {
        status = "dangerous"
      }

      setResult({
        status,
        riskScore,
        failedChecks,
        totalChecks: SECURITY_CHECKS.length,
      })

      // Add to history
      addToHistory(urlToScan, status, riskScore)
    } catch {
      setError("Invalid URL format. Please enter a valid URL.")
    } finally {
      setIsScanning(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      scanUrl()
    }
  }

  // Scam keywords for local detection
  const SCAM_KEYWORDS = [
    { keyword: "otp", signal: "Asks for OTP (One-Time Password)" },
    { keyword: "verify", signal: "Requests account verification" },
    { keyword: "prize", signal: "Mentions winning a prize" },
    { keyword: "winner", signal: "Claims you are a winner" },
    { keyword: "free money", signal: "Promises free money" },
    { keyword: "click now", signal: "Uses urgent call-to-action" },
    { keyword: "urgent", signal: "Creates false urgency" },
    { keyword: "bank account", signal: "Requests bank account details" },
    { keyword: "kyc", signal: "Fake KYC update request" },
    { keyword: "lottery", signal: "Mentions lottery winnings" },
    { keyword: "blocked", signal: "Threatens account blocking" },
    { keyword: "suspended", signal: "Claims account suspension" },
    { keyword: "expired", signal: "False expiration warning" },
    { keyword: "immediately", signal: "Creates pressure to act fast" },
    { keyword: "limited time", signal: "Uses time pressure tactics" },
    { keyword: "claim", signal: "Requests you to claim something" },
    { keyword: "congratulations", signal: "Unsolicited congratulations" },
    { keyword: "failed", signal: "Fake transaction failure" },
    { keyword: "upi", signal: "Mentions UPI payment system" },
    { keyword: "deducted", signal: "Threatens money deduction" },
    { keyword: ".tk", signal: "Contains suspicious domain (.tk)" },
    { keyword: ".xyz", signal: "Contains suspicious domain (.xyz)" },
    { keyword: ".ml", signal: "Contains suspicious domain (.ml)" },
    { keyword: "call now", signal: "Pressures immediate phone call" },
    { keyword: "sbi", signal: "Impersonates SBI bank" },
    { keyword: "hdfc", signal: "Impersonates HDFC bank" },
    { keyword: "icici", signal: "Impersonates ICICI bank" },
    // Indian payment apps
    { keyword: "paytm", signal: "Mentions Paytm payment app" },
    { keyword: "phonepe", signal: "Mentions PhonePe payment app" },
    { keyword: "gpay", signal: "Mentions Google Pay" },
    { keyword: "bhim", signal: "Mentions BHIM UPI app" },
    // Indian identity documents
    { keyword: "aadhaar", signal: "Requests Aadhaar details" },
    { keyword: "pan card", signal: "Requests PAN card information" },
    { keyword: "kyc pending", signal: "Fake KYC pending notification" },
    { keyword: "account blocked", signal: "Threatens account blocking" },
    // Indian currency references
    { keyword: "rs.", signal: "Mentions Indian Rupees" },
    { keyword: "lakh", signal: "Mentions large sum (lakh)" },
    { keyword: "crore", signal: "Mentions large sum (crore)" },
    // Additional scam phrases
    { keyword: "lottery won", signal: "Claims lottery winnings" },
    { keyword: "gift voucher", signal: "Promises free gift voucher" },
    { keyword: "otp share", signal: "Asks to share OTP" },
    { keyword: "screen share", signal: "Requests screen sharing" },
    { keyword: "customer care", signal: "Impersonates customer care" },
    { keyword: "refund pending", signal: "Fake refund notification" },
  ]

  // Local message analysis function
  const analyzeMessageLocally = (text: string): MessageScanResult => {
    const lowerText = text.toLowerCase()
    const detectedSignals: string[] = []

    // Check for each scam keyword
    for (const { keyword, signal } of SCAM_KEYWORDS) {
      if (lowerText.includes(keyword)) {
        detectedSignals.push(signal)
      }
    }

    // Calculate threat score based on number of keywords found
    const keywordCount = detectedSignals.length
    let threatScore = Math.min(keywordCount * 15, 100)

    // Determine verdict
    let verdict: "SAFE" | "SUSPICIOUS" | "DANGEROUS"
    let summary: string

    if (keywordCount >= 3) {
      verdict = "DANGEROUS"
      threatScore = Math.max(threatScore, 70)
      summary = `High-risk message detected with ${keywordCount} scam indicators. This message shows multiple signs of a phishing or fraud attempt. Do not click any links or share personal information.`
    } else if (keywordCount >= 2) {
      verdict = "SUSPICIOUS"
      threatScore = Math.max(threatScore, 40)
      summary = `Suspicious message with ${keywordCount} warning signs detected. Exercise caution and verify the sender through official channels before taking any action.`
    } else if (keywordCount === 1) {
      verdict = "SUSPICIOUS"
      threatScore = 25
      summary = `One potential warning sign detected. While this could be legitimate, verify the message source before responding or clicking any links.`
    } else {
      verdict = "SAFE"
      threatScore = 0
      summary = "No common scam indicators detected. However, always exercise caution with unsolicited messages."
    }

    return {
      verdict,
      threat_score: threatScore,
      signals: detectedSignals.slice(0, 6), // Limit to top 6 signals
      summary,
    }
  }

  // Message scanning with animated steps
  const scanMessage = async () => {
    if (!message.trim()) return

    setIsMessageScanning(true)
    setMessageResult(null)
    setMessageError(null)

    // Initialize scanning steps
    const steps: ScanningStep[] = [
      { label: "Analyzing message content...", completed: false, active: true },
      { label: "Detecting urgency patterns...", completed: false, active: false },
      { label: "Checking for phishing indicators...", completed: false, active: false },
      { label: "Identifying impersonation attempts...", completed: false, active: false },
      { label: "Generating threat assessment...", completed: false, active: false },
    ]
    setScanningSteps(steps)

    // Animate through steps
    const animateSteps = async () => {
      for (let i = 0; i < steps.length; i++) {
        await new Promise((resolve) => setTimeout(resolve, 600))
        setScanningSteps((prev) =>
          prev.map((step, idx) => ({
            ...step,
            completed: idx < i + 1,
            active: idx === i + 1,
          }))
        )
      }
    }

    // Run animation
    await animateSteps()

    // Perform local analysis
    const result = analyzeMessageLocally(message.trim())

    // Small delay before showing result
    await new Promise((resolve) => setTimeout(resolve, 400))

    setMessageResult(result)
    setIsMessageScanning(false)
    setScanningSteps([])
  }

  // Load example message
  const loadExample = (text: string) => {
    setMessage(text)
    setMessageResult(null)
    setMessageError(null)
  }

  // Get color based on status
  const getStatusColor = (status: "safe" | "warning" | "dangerous") => {
    switch (status) {
      case "safe":
        return "#00ff88"
      case "warning":
        return "#ffaa00"
      case "dangerous":
        return "#ff4444"
    }
  }

  // Get color based on verdict
  const getVerdictColor = (verdict: "SAFE" | "SUSPICIOUS" | "DANGEROUS") => {
    switch (verdict) {
      case "SAFE":
        return "#00ff88"
      case "SUSPICIOUS":
        return "#ffaa00"
      case "DANGEROUS":
        return "#ff4444"
    }
  }

  // Get risk score color (gradient from green to red)
  const getRiskScoreColor = (score: number) => {
    if (score === 0) return "#00ff88"
    if (score < 30) return "#ffaa00"
    return "#ff4444"
  }

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-start p-6 pt-12">
      {/* Main Container */}
      <div className="w-full max-w-2xl">
        {/* Title */}
        <h1 className="text-4xl md:text-5xl font-bold text-center mb-2 text-white">
          🔐 SafeCheck
        </h1>
        <p className="text-center text-[#00ff88] text-lg mb-8 font-medium tracking-wide">
          Scam Detector
        </p>

        {/* Tab Navigation */}
        <div className="flex gap-2 mb-6 bg-zinc-900 p-1.5 rounded-xl">
          <button
            onClick={() => setActiveTab("url")}
            className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all flex items-center justify-center gap-2 ${
              activeTab === "url"
                ? "bg-[#00ff88] text-black"
                : "text-zinc-400 hover:text-white hover:bg-zinc-800"
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
            </svg>
            URL Scanner
          </button>
          <button
            onClick={() => setActiveTab("message")}
            className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all flex items-center justify-center gap-2 ${
              activeTab === "message"
                ? "bg-[#00ff88] text-black"
                : "text-zinc-400 hover:text-white hover:bg-zinc-800"
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
            </svg>
            Message Scanner
          </button>
        </div>

        {/* URL Scanner Tab */}
        {activeTab === "url" && (
          <>
            {/* Scanner Card */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-8 shadow-2xl shadow-[#00ff8810]">
              {/* Input Section */}
              <div className="mb-6">
                <label htmlFor="url-input" className="block text-zinc-400 text-sm mb-2 font-medium">
                  Enter URL to scan
                </label>
                <input
                  id="url-input"
                  type="text"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  onKeyDown={handleKeyPress}
                  placeholder="https://example.com"
                  className="w-full bg-black border border-zinc-700 rounded-xl px-5 py-4 text-white placeholder-zinc-600 focus:outline-none focus:border-[#00ff88] focus:ring-1 focus:ring-[#00ff88] transition-all text-lg"
                  disabled={isScanning}
                />
              </div>

              {/* Scan Button */}
              <button
                onClick={scanUrl}
                disabled={isScanning || !url.trim()}
                className="w-full bg-[#00ff88] hover:bg-[#00dd77] disabled:bg-zinc-700 disabled:cursor-not-allowed text-black font-bold py-4 px-6 rounded-xl transition-all text-lg flex items-center justify-center gap-3"
              >
                {isScanning ? (
                  <>
                    <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                        fill="none"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      />
                    </svg>
                    Analyzing URL...
                  </>
                ) : (
                  <>
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                      />
                    </svg>
                    Scan Now
                  </>
                )}
              </button>
            </div>

            {/* Error Section */}
            {error && (
              <div className="mt-8 rounded-2xl p-6 border-2 bg-[#ff444410] border-[#ff4444] animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex items-center gap-3">
                  <svg className="w-6 h-6 text-[#ff4444] flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                  <p className="text-[#ff4444] text-sm">{error}</p>
                </div>
              </div>
            )}

            {/* Result Section */}
            {result && (
              <div
                className="mt-8 rounded-2xl p-8 border-2 transition-all animate-in fade-in slide-in-from-bottom-4 duration-500"
                style={{
                  backgroundColor: `${getStatusColor(result.status)}10`,
                  borderColor: getStatusColor(result.status),
                }}
              >
                {/* Risk Score Display */}
                <div className="flex flex-col items-center mb-6">
                  <div
                    className="relative w-32 h-32 mb-4"
                    style={{ color: getRiskScoreColor(result.riskScore) }}
                  >
                    {/* Circular progress background */}
                    <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="none"
                        opacity="0.2"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="none"
                        strokeLinecap="round"
                        strokeDasharray={`${result.riskScore * 2.83} 283`}
                      />
                    </svg>
                    {/* Score text in center */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className="text-3xl font-bold" style={{ color: getRiskScoreColor(result.riskScore) }}>
                        {result.riskScore}
                      </span>
                      <span className="text-xs text-zinc-400">/ 100</span>
                    </div>
                  </div>
                  <p className="text-zinc-400 text-sm font-medium">RISK SCORE</p>
                </div>

                {/* Status Badge */}
                <div className="flex items-center justify-center gap-3 mb-6">
                  {result.status === "safe" ? (
                    <svg className="w-10 h-10" style={{ color: getStatusColor(result.status) }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                  ) : result.status === "warning" ? (
                    <svg className="w-10 h-10" style={{ color: getStatusColor(result.status) }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                  ) : (
                    <svg className="w-10 h-10" style={{ color: getStatusColor(result.status) }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                    </svg>
                  )}
                  <span
                    className="text-3xl font-bold uppercase"
                    style={{ color: getStatusColor(result.status) }}
                  >
                    {result.status}
                  </span>
                </div>

                {/* Checks Summary */}
                <div className="bg-black/30 rounded-xl p-4 mb-6">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-zinc-400">Security checks passed:</span>
                    <span className="font-semibold" style={{ color: getStatusColor(result.status) }}>
                      {result.totalChecks - result.failedChecks.length} / {result.totalChecks}
                    </span>
                  </div>
                </div>

                {/* Failed Checks List */}
                {result.failedChecks.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                      <svg className="w-5 h-5 text-[#ff4444]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                      </svg>
                      Issues Detected
                    </h3>
                    <div className="space-y-3">
                      {result.failedChecks.map((check, index) => (
                        <div
                          key={index}
                          className="bg-black/40 border border-zinc-800 rounded-lg p-4"
                        >
                          <div className="flex items-start gap-3">
                            <svg className="w-5 h-5 text-[#ff4444] flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                            <div>
                              <p className="text-white font-medium text-sm">{check.name}</p>
                              <p className="text-zinc-500 text-xs mt-1">{check.description}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Passed Checks (when all pass) */}
                {result.failedChecks.length === 0 && (
                  <div className="mb-6">
                    <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                      <svg className="w-5 h-5 text-[#00ff88]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      All Checks Passed
                    </h3>
                    <div className="bg-black/40 border border-zinc-800 rounded-lg p-4">
                      <ul className="space-y-2 text-sm text-zinc-400">
                        <li className="flex items-center gap-2">
                          <svg className="w-4 h-4 text-[#00ff88]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          No suspicious keywords detected
                        </li>
                        <li className="flex items-center gap-2">
                          <svg className="w-4 h-4 text-[#00ff88]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          Domain extension is trustworthy
                        </li>
                        <li className="flex items-center gap-2">
                          <svg className="w-4 h-4 text-[#00ff88]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          Uses secure HTTPS connection
                        </li>
                        <li className="flex items-center gap-2">
                          <svg className="w-4 h-4 text-[#00ff88]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          Normal subdomain structure
                        </li>
                        <li className="flex items-center gap-2">
                          <svg className="w-4 h-4 text-[#00ff88]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          Uses proper domain name
                        </li>
                      </ul>
                    </div>
                  </div>
                )}

                {/* Scanned URL */}
                <p className="text-center text-zinc-400 text-sm break-all">
                  Scanned: <span className="text-zinc-300">{scannedUrl}</span>
                </p>
              </div>
            )}

            {/* Scan History Section */}
            {history.length > 0 && (
              <div className="mt-10 bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-white font-semibold text-lg flex items-center gap-2">
                    <svg className="w-5 h-5 text-[#00ff88]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Scan History
                  </h2>
                  <button
                    onClick={clearHistory}
                    className="text-zinc-500 hover:text-[#ff4444] text-sm flex items-center gap-1 transition-colors"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                    Clear History
                  </button>
                </div>

                <div className="space-y-3">
                  {history.map((item) => (
                    <div
                      key={item.id}
                      className="bg-black/50 border border-zinc-800 rounded-xl p-4 hover:border-zinc-700 transition-colors"
                    >
                      <div className="flex items-center justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <p className="text-white text-sm font-medium truncate" title={item.url}>
                            {item.url}
                          </p>
                          <p className="text-zinc-500 text-xs mt-1">
                            {formatTime(item.timestamp)}
                          </p>
                        </div>
                        <div className="flex items-center gap-3 flex-shrink-0">
                          {/* Risk Score Badge */}
                          <div
                            className="px-2 py-1 rounded-md text-xs font-semibold"
                            style={{
                              backgroundColor: `${getRiskScoreColor(item.riskScore)}20`,
                              color: getRiskScoreColor(item.riskScore),
                            }}
                          >
                            {item.riskScore}/100
                          </div>
                          {/* Status Badge */}
                          <div
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold uppercase"
                            style={{
                              backgroundColor: `${getStatusColor(item.status)}20`,
                              color: getStatusColor(item.status),
                            }}
                          >
                            {item.status === "safe" ? (
                              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                              </svg>
                            ) : item.status === "warning" ? (
                              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                              </svg>
                            ) : (
                              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                              </svg>
                            )}
                            {item.status}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <p className="text-zinc-600 text-xs mt-4 text-center">
                  Showing last {history.length} scan{history.length !== 1 ? "s" : ""} (max {MAX_HISTORY_ITEMS})
                </p>
              </div>
            )}
          </>
        )}

        {/* Message Scanner Tab */}
        {activeTab === "message" && (
          <>
            {/* Scanner Card */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-8 shadow-2xl shadow-[#00ff8810]">
              {/* Example Buttons */}
              <div className="mb-6">
                <p className="text-zinc-400 text-sm mb-3 font-medium">Try an example:</p>
                <div className="flex flex-wrap gap-2">
                  {EXAMPLE_MESSAGES.map((example, index) => (
                    <button
                      key={index}
                      onClick={() => loadExample(example.text)}
                      className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 hover:border-[#00ff88] text-zinc-300 hover:text-white text-xs rounded-lg transition-all"
                    >
                      {example.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Textarea Section */}
              <div className="mb-6">
                <label htmlFor="message-input" className="block text-zinc-400 text-sm mb-2 font-medium">
                  Paste SMS, WhatsApp message, or email text
                </label>
                <textarea
                  id="message-input"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Paste the suspicious message here..."
                  rows={6}
                  className="w-full bg-black border border-zinc-700 rounded-xl px-5 py-4 text-white placeholder-zinc-600 focus:outline-none focus:border-[#00ff88] focus:ring-1 focus:ring-[#00ff88] transition-all text-base resize-none"
                  disabled={isMessageScanning}
                />
              </div>

              {/* Scan Button */}
              <button
                onClick={scanMessage}
                disabled={isMessageScanning || !message.trim()}
                className="w-full bg-[#00ff88] hover:bg-[#00dd77] disabled:bg-zinc-700 disabled:cursor-not-allowed text-black font-bold py-4 px-6 rounded-xl transition-all text-lg flex items-center justify-center gap-3"
              >
                {isMessageScanning ? (
                  <>
                    <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                        fill="none"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      />
                    </svg>
                    Analyzing Message...
                  </>
                ) : (
                  <>
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                      />
                    </svg>
                    Scan Message
                  </>
                )}
              </button>
            </div>

            {/* Scanning Animation */}
            {isMessageScanning && scanningSteps.length > 0 && (
              <div className="mt-8 bg-zinc-900 border border-zinc-800 rounded-2xl p-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
                <div className="space-y-3">
                  {scanningSteps.map((step, index) => (
                    <div
                      key={index}
                      className={`flex items-center gap-3 transition-all duration-300 ${
                        step.completed ? "opacity-100" : step.active ? "opacity-100" : "opacity-40"
                      }`}
                    >
                      {step.completed ? (
                        <svg className="w-5 h-5 text-[#00ff88]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      ) : step.active ? (
                        <svg className="w-5 h-5 text-[#00ff88] animate-spin" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                      ) : (
                        <div className="w-5 h-5 rounded-full border-2 border-zinc-600" />
                      )}
                      <span className={`text-sm ${step.completed || step.active ? "text-white" : "text-zinc-500"}`}>
                        {step.label}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Error Section */}
            {messageError && (
              <div className="mt-8 rounded-2xl p-6 border-2 bg-[#ff444410] border-[#ff4444] animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex items-center gap-3">
                  <svg className="w-6 h-6 text-[#ff4444] flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                  <p className="text-[#ff4444] text-sm">{messageError}</p>
                </div>
              </div>
            )}

            {/* Message Result Section */}
            {messageResult && (
              <div
                className="mt-8 rounded-2xl p-8 border-2 transition-all animate-in fade-in slide-in-from-bottom-4 duration-500"
                style={{
                  backgroundColor: `${getVerdictColor(messageResult.verdict)}10`,
                  borderColor: getVerdictColor(messageResult.verdict),
                }}
              >
                {/* Threat Score Display */}
                <div className="flex flex-col items-center mb-6">
                  <div
                    className="relative w-32 h-32 mb-4"
                    style={{ color: getRiskScoreColor(messageResult.threat_score) }}
                  >
                    {/* Circular progress background */}
                    <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="none"
                        opacity="0.2"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="none"
                        strokeLinecap="round"
                        strokeDasharray={`${messageResult.threat_score * 2.83} 283`}
                      />
                    </svg>
                    {/* Score text in center */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className="text-3xl font-bold" style={{ color: getRiskScoreColor(messageResult.threat_score) }}>
                        {messageResult.threat_score}
                      </span>
                      <span className="text-xs text-zinc-400">/ 100</span>
                    </div>
                  </div>
                  <p className="text-zinc-400 text-sm font-medium">THREAT SCORE</p>
                </div>

                {/* Verdict Badge */}
                <div className="flex items-center justify-center gap-3 mb-6">
                  {messageResult.verdict === "SAFE" ? (
                    <svg className="w-10 h-10" style={{ color: getVerdictColor(messageResult.verdict) }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                  ) : messageResult.verdict === "SUSPICIOUS" ? (
                    <svg className="w-10 h-10" style={{ color: getVerdictColor(messageResult.verdict) }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                  ) : (
                    <svg className="w-10 h-10" style={{ color: getVerdictColor(messageResult.verdict) }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                    </svg>
                  )}
                  <span
                    className="text-3xl font-bold uppercase"
                    style={{ color: getVerdictColor(messageResult.verdict) }}
                  >
                    {messageResult.verdict}
                  </span>
                </div>

                {/* Summary */}
                <div className="bg-black/30 rounded-xl p-4 mb-6">
                  <p className="text-zinc-300 text-sm leading-relaxed">{messageResult.summary}</p>
                </div>

                {/* Threat Signals */}
                <div>
                  <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                    {messageResult.verdict === "SAFE" ? (
                      <svg className="w-5 h-5 text-[#00ff88]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    ) : (
                      <svg className="w-5 h-5 text-[#ff4444]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                      </svg>
                    )}
                    {messageResult.verdict === "SAFE" ? "Analysis Results" : "Threat Signals Detected"}
                  </h3>
                  <div className="space-y-3">
                    {messageResult.signals.map((signal, index) => (
                      <div
                        key={index}
                        className="bg-black/40 border border-zinc-800 rounded-lg p-4"
                      >
                        <div className="flex items-start gap-3">
                          {messageResult.verdict === "SAFE" ? (
                            <svg className="w-5 h-5 text-[#00ff88] flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          ) : (
                            <svg className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: getVerdictColor(messageResult.verdict) }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                            </svg>
                          )}
                          <p className="text-white text-sm">{signal}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </>
        )}

        {/* Footer */}
        <p className="text-center text-zinc-600 text-xs mt-10">
          SafeCheck analyzes URLs and messages for common scam and phishing indicators.
          <br />
          Always exercise caution when visiting unfamiliar websites or responding to unknown messages.
        </p>
      </div>
    </div>
  )
}
