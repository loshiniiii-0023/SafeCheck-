import { generateText, Output } from 'ai'
import * as z from 'zod'

// Schema for Claude's structured response
const scanResultSchema = z.object({
  verdict: z.enum(['SAFE', 'SUSPICIOUS', 'DANGEROUS']).describe('Overall safety verdict'),
  threat_score: z.number().min(0).max(100).describe('Threat score from 0-100'),
  signals: z.array(z.string()).describe('Array of 3-4 specific threat signals or reasons'),
  summary: z.string().describe('Brief summary explaining the verdict'),
})

export async function POST(req: Request) {
  try {
    const { message } = await req.json()

    if (!message || typeof message !== 'string') {
      return Response.json({ error: 'Message is required' }, { status: 400 })
    }

    const { output } = await generateText({
      model: 'anthropic/claude-sonnet-4-20250514',
      output: Output.object({
        schema: scanResultSchema,
      }),
      messages: [
        {
          role: 'user',
          content: `You are a cybersecurity expert analyzing messages for scam and phishing indicators. Analyze the following SMS, WhatsApp message, or email text for potential scams or fraud.

IMPORTANT: You must analyze this specific message and provide a detailed assessment.

Message to analyze:
"""
${message}
"""

Analyze this message for:
1. Urgency language or pressure tactics (e.g., "act now", "immediate action required", "expires today")
2. Requests for sensitive information (OTP, bank details, passwords, PAN/Aadhaar)
3. Impersonation of banks, government agencies, or trusted companies (SBI, HDFC, RBI, UIDAI, etc.)
4. Suspicious links or URL patterns
5. Prize/lottery scams or unrealistic offers
6. Poor grammar or spelling (common in scams)
7. Threats of account suspension or legal action
8. Requests to call unknown numbers or download apps

Based on your analysis:
- SAFE: No scam indicators found, appears to be legitimate
- SUSPICIOUS: Some concerning elements but not definitively a scam
- DANGEROUS: Clear scam indicators, high risk of fraud

Provide exactly 3-4 specific signals explaining your verdict. Be specific about what you found in THIS message.`,
        },
      ],
    })

    return Response.json(output)
  } catch (error) {
    console.error('Scan error:', error)
    return Response.json(
      { error: 'Failed to analyze message' },
      { status: 500 }
    )
  }
}
