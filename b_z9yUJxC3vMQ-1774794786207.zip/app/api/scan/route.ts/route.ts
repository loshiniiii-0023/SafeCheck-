import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const { url } = await req.json();

    // Send URL to VirusTotal
    const submitResponse = await fetch(
      "https://www.virustotal.com/api/v3/urls",
      {
        method: "POST",
        headers: {
          "x-apikey": "YOUR_API_KEY",
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({ url }),
      }
    );

    const submitData = await submitResponse.json();
    const analysisId = submitData.data.id;

    // Get scan result
    const reportResponse = await fetch(
      `https://www.virustotal.com/api/v3/analyses/${analysisId}`,
      {
        method: "GET",
        headers: {
          "x-apikey": "3b90c86e6057fdb8c9c583ee225020cba6ecba3014fd391c7b52a4ed59a30999",
        },
      }
    );

    const reportData = await reportResponse.json();

    return NextResponse.json(reportData);
  } catch (error) {
    return NextResponse.json({ error: "Scan failed" }, { status: 500 });
  }
}